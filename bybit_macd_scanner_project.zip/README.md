# Bybit MACD Scanner (Render)

This is a minimal skeleton to run on **Render** as a **Background Worker**.

## Files
- `bybit_macd_scanner.py` — main script (entrypoint).
- `requirements.txt` — kept empty so deployment doesn't fail; add your libraries as needed (e.g., `pandas`, `ta`, `python-telegram-bot`, `pybit`).

## Deploy to Render
1. Push these files to GitHub (root of your repo).
2. Create a **Background Worker** in Render linked to your repo.
3. **Build Command**: `pip install -r requirements.txt`
4. **Start Command**: `python bybit_macd_scanner.py`
5. In **Settings → Environment**, add:
   - `TELEGRAM_TOKEN=...` (from @BotFather, never commit to GitHub)

## Notes
- If you move the script into a folder, update the Start Command accordingly, e.g., `python src/bybit_macd_scanner.py`.
- Keep secrets out of code. Use environment variables.
